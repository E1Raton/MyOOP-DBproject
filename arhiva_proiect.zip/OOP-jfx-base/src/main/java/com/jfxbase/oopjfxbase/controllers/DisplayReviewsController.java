package com.jfxbase.oopjfxbase.controllers;

import com.jfxbase.oopjfxbase.dbcontrollers.HorseController;
import com.jfxbase.oopjfxbase.dbcontrollers.HorseReviewController;
import com.jfxbase.oopjfxbase.utils.HorseReviewUtil;
import com.jfxbase.oopjfxbase.utils.SceneController;
import com.jfxbase.oopjfxbase.utils.enums.SCENE_IDENTIFIER;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.SQLException;
import java.util.*;

public class DisplayReviewsController extends SceneController implements Initializable {
    @FXML
    private CheckBox sortByHorseSel;
    @FXML
    private Button goBackButton;
    @FXML
    private TableColumn<HorseReviewUtil, String> reviewCol;
    @FXML
    private TableColumn<HorseReviewUtil, String> horseCol;
    @FXML
    private TableColumn<HorseController, Integer> gradeCol;
    @FXML
    private TableView<HorseReviewUtil> displayReviewsTable;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        this.loadDate();
    }

    private void loadDate() {
        this.horseCol.setCellValueFactory(new PropertyValueFactory<>("nameOfHorse"));
        this.reviewCol.setCellValueFactory(new PropertyValueFactory<>("review"));
        this.gradeCol.setCellValueFactory(new PropertyValueFactory<>("grade"));

        this.refreshTable();
    }

    private ArrayList<HorseReviewUtil> getAllReviews() {
        Set<HorseReviewUtil> auxList = new HashSet<>();

        HorseReviewController horseReviewController = new HorseReviewController();

        try {
            auxList = horseReviewController.getAllReviews();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return new ArrayList<>(auxList);
    }
    private void sortByHorse() {
        ArrayList<HorseReviewUtil> sortedReviews = this.getAllReviews();
        sortedReviews.sort(Comparator.comparing(HorseReviewUtil::getNameOfHorse));
        this.displayReviewsTable.setItems(FXCollections.observableArrayList(sortedReviews));
    }

    private void refreshTable() {
        this.displayReviewsTable.setItems(FXCollections.observableArrayList(this.getAllReviews()));
    }

    public void onGoBackClick(ActionEvent actionEvent) {
        this.changeScene(SCENE_IDENTIFIER.HELLO);
    }

    public void onSortByHorseCB(ActionEvent actionEvent) {
        if (this.sortByHorseSel.isSelected()) this.sortByHorse();
        if (!this.sortByHorseSel.isSelected()) this.refreshTable();
    }
}
