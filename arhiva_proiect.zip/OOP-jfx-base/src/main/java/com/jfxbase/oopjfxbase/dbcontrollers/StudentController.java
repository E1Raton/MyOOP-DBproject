package com.jfxbase.oopjfxbase.dbcontrollers;

import com.jfxbase.oopjfxbase.mappedentities.UserEntity;

import java.sql.*;

public class StudentController extends DBController {
    public String addStudentToDB(Integer id) {
        String msg;
        try {
            Connection connectionToPostgres = DriverManager.getConnection(super.DB_URL, super.USERNAME, super.PASSWORD);

            Statement stmt = connectionToPostgres.createStatement();
            String sql = "INSERT INTO student (student_id) " + "VALUES (?)";

            PreparedStatement preparedStatement = connectionToPostgres.prepareStatement(sql);
            preparedStatement.setInt(1, id);

            int addedRows = preparedStatement.executeUpdate();
            if (addedRows > 0) {
                msg = "Successful insertion into database.";
            }
            else {
                msg = "Unsuccessful insertion into database.";
            }

            stmt.close();
            connectionToPostgres.close();
        }
        catch (SQLException e) {
            msg = "Error establishing the connection.";
        }
        return msg;
    }

    public Boolean findStudentInDB(Integer id) {
        boolean foundIt = false;
        try {
            Connection connectionToPostgres = DriverManager.getConnection(super.DB_URL, super.USERNAME, super.PASSWORD);

            String sql = "select * from student where student_id = ?";

            PreparedStatement preparedStatement = connectionToPostgres.prepareStatement(sql);
            preparedStatement.setInt(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) foundIt = true;

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return foundIt;
    }
}
