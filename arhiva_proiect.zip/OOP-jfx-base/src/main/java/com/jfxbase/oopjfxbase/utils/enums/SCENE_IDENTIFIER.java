package com.jfxbase.oopjfxbase.utils.enums;

public enum SCENE_IDENTIFIER {
    HELLO("hello-view.fxml"),
    SIGN_IN("sign-in-view.fxml"),
    LOGGED_IN("logged-in-view.fxml"),
    PROGRAM_COURSE("program-course-view.fxml"),
    REVIEW("review-view.fxml"),
    DISPLAY_REVIEWS("display-reviews-view.fxml"),
    LOGGED_IN_INSTRUCTOR("logged-in-instructor-view.fxml"),
    DISPLAY_COURSES("display-courses-view.fxml"),
    GOOD_BYE("good-bye-view.fxml");

    public final String label;

    SCENE_IDENTIFIER(String label) {
        this.label = label;
    }
}
