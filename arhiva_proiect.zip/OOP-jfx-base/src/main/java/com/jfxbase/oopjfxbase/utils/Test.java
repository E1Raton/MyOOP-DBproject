package com.jfxbase.oopjfxbase.utils;

import com.jfxbase.oopjfxbase.dbcontrollers.*;
import com.jfxbase.oopjfxbase.mappedentities.HorseEntity;
import com.jfxbase.oopjfxbase.mappedentities.HorseRidingCourseEntity;
import com.jfxbase.oopjfxbase.mappedentities.UserEntity;
import javafx.collections.FXCollections;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class Test {
    public static void main(String[] args) {
//        UserEntity instanceToAdd = new UserEntity("horserider2@gmail.com", "P@ssWord");
//        UserController myController = new UserController();
//        String ctrlString = myController.addUserToDB(instanceToAdd);
//        System.out.println(ctrlString);

//        UserEntity foundUser = null;
//
//        try {
//            UserController myController = new UserController();
//            foundUser = myController.findUserInDB("horserider2@gmail.com", "PassWord");
//        }
//        catch (SQLException e) {
//            e.printStackTrace();
//        }
//
//        if (foundUser == null) {
//            System.out.println("Invalid email or password.");
//        }

//        Integer horseId = 1;
//        LocalDate courseDate = LocalDate.of(2024, 1, 3);
//        String startHour = "10:00";
//
//        HorseRidingCourseController myController = new HorseRidingCourseController();
//
//        Boolean myBoolean = false;
//
//        try {
//            myBoolean = myController.checkForCourse(horseId, courseDate, startHour);
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//
//        System.out.println(myBoolean);

//        Integer userId = 1;
//        HorseController myController = new HorseController();
//        Set<HorseEntity> reviewedHorses = new HashSet<>();
//        Set<HorseEntity> allHorses = new HashSet<>();
//
//        try {
//            reviewedHorses = myController.getReviewedHorses(userId);
//        } catch (SQLException e) {
//            System.out.println(e.getMessage());
//        }
//
//        try {
//            allHorses = myController.getAllHorses();
//        } catch (SQLException e) {
//            System.out.println(e.getMessage());
//        }
//
//        Set<HorseEntity> horsesToReview = new HashSet<>(allHorses);
//        horsesToReview.removeAll(reviewedHorses);
//
//        for (HorseEntity horse : horsesToReview) {
//            System.out.println(horse.getHorseName());
//        }

//        HorseReviewController horseReviewController = new HorseReviewController();
//
//        Set<HorseReviewUtil> horseReviews = new HashSet<>();
//
//        try {
//            horseReviews = horseReviewController.getAllReviews();
//        } catch (SQLException e) {
//            System.out.println(e.getMessage());
//        }
//
//        for (HorseReviewUtil aut : horseReviews) {
//            System.out.println(aut.getNameOfHorse() + " " + aut.getReview());
//        }

//        HorseRidingCourseController instructorController = new HorseRidingCourseController();
//        ArrayList<InstructorCourseUtil> instructorCourses = new ArrayList<>();
//
//        instructorCourses = instructorController.getAllCourses();
//
//        for (InstructorCourseUtil instructorCourse : instructorCourses) {
//            System.out.println(instructorCourse.getNameOfInstructor() + " " +
//                    instructorCourse.getNameOfStudent() + " " +
//                    instructorCourse.getNameOfHorse() + " " +
//                    instructorCourse.getDateOfCourse() + " " +
//                    instructorCourse.getStartingHour());
//        }

//        HorseRidingCourseController controller = new HorseRidingCourseController();
//        ArrayList<InstructorCourseUtil> myCourses = controller.getAllCourses();
//
//        myCourses.removeIf(course -> course.getDateOfCourse().isAfter(LocalDate.now()));
//        myCourses.removeIf(course -> !course.getNameOfStudent().equals(LogInSession.getLoggedInUser().getFirstName() + " " + LogInSession.getLoggedInUser().getLastName()));
//
//        for (InstructorCourseUtil instructorCourse : myCourses) {
//            System.out.println(instructorCourse.getNameOfInstructor() + " " +
//                    instructorCourse.getNameOfStudent() + " " +
//                    instructorCourse.getNameOfHorse() + " " +
//                    instructorCourse.getDateOfCourse() + " " +
//                    instructorCourse.getStartingHour());
//        }

        HorseRidingCourseController horseRidingCourseController = new HorseRidingCourseController();
        LocalDate myLocalDate = LocalDate.of(2024, 1, 3);
        HorseRidingCourseEntity horseRidingCourse = horseRidingCourseController.getCourse(1, myLocalDate, "10:00");
        System.out.println(horseRidingCourse.getCourseId());
    }
}
