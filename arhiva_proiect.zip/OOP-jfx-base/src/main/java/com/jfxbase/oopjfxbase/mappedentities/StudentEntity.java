package com.jfxbase.oopjfxbase.mappedentities;

public class StudentEntity extends UserEntity {

}
