package com.jfxbase.oopjfxbase.mappedentities;

public class OwnerEntity extends UserEntity {

}
