package com.jfxbase.oopjfxbase.controllers;

import com.jfxbase.oopjfxbase.dbcontrollers.InstructorController;
import com.jfxbase.oopjfxbase.dbcontrollers.StudentController;
import com.jfxbase.oopjfxbase.dbcontrollers.UserController;
import com.jfxbase.oopjfxbase.mappedentities.UserEntity;
import com.jfxbase.oopjfxbase.utils.LogInSession;
import com.jfxbase.oopjfxbase.utils.enums.SCENE_IDENTIFIER;
import com.jfxbase.oopjfxbase.utils.SceneController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.AccessibleRole;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.text.Text;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class HelloController extends SceneController {
    @FXML
    private ToggleButton toggleButton;

    @FXML
    private TextField emailField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Text ControlText;
    @FXML
    private Text shownPassword;

    @FXML
    protected void onLogInClick() {
        String email = emailField.getText();
        String password = passwordField.getText();

        UserController userController = new UserController();
        UserEntity loggedInUser = new UserEntity();

        try {
            loggedInUser = userController.findUserInDB(email, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (loggedInUser == null) {
            ControlText.setText("Invalid email or password.");
        }
        else {
            StudentController studentController = new StudentController();
            if (studentController.findStudentInDB(loggedInUser.getUserId())) this.changeScene(SCENE_IDENTIFIER.LOGGED_IN);

            InstructorController instructorController = new InstructorController();
            if (instructorController.findInstructorInDB(loggedInUser.getUserId())) this.changeScene(SCENE_IDENTIFIER.LOGGED_IN_INSTRUCTOR);

            LogInSession.setLoggedInUser(loggedInUser);
            this.emailField.clear();
            this.passwordField.clear();
            this.ControlText.setText("");
        }
    }

    @FXML
    protected void onSignUpClick() { this.changeScene(SCENE_IDENTIFIER.SIGN_IN);}

    public void onSeeReviewsClick(ActionEvent actionEvent) {
        this.changeScene(SCENE_IDENTIFIER.DISPLAY_REVIEWS);
    }

    public void onToggleClick(ActionEvent actionEvent) {
        if (this.toggleButton.isSelected()) {
            this.shownPassword.setText(this.passwordField.getText());
        } else {
            this.shownPassword.setText("");
        }
    }

}