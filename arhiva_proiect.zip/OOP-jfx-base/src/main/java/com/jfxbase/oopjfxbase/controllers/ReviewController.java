package com.jfxbase.oopjfxbase.controllers;

import com.jfxbase.oopjfxbase.dbcontrollers.HorseController;
import com.jfxbase.oopjfxbase.dbcontrollers.HorseReviewController;
import com.jfxbase.oopjfxbase.mappedentities.HorseEntity;
import com.jfxbase.oopjfxbase.mappedentities.HorseReviewEntity;
import com.jfxbase.oopjfxbase.utils.LogInSession;
import com.jfxbase.oopjfxbase.utils.SceneController;
import com.jfxbase.oopjfxbase.utils.UtilitiesClass;
import com.jfxbase.oopjfxbase.utils.enums.SCENE_IDENTIFIER;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.text.Text;

import java.net.URL;
import java.sql.SQLException;
import java.util.*;

public class ReviewController extends SceneController implements Initializable {
    @FXML
    private ComboBox<Integer> gradeBox;
    @FXML
    private Text anotherWarningText;
    @FXML
    private Button cancelButton;
    @FXML
    private Button submitButton;
    @FXML
    private ComboBox<String> horseChoice;
    @FXML
    private Text horseWarningText;
    @FXML
    private TextArea reviewField;
    private Set<HorseEntity> allHorses;

    public void initialize(URL url, ResourceBundle resourceBundle) {

        ArrayList<String> comboChoices = new ArrayList<>();

        HorseController horseController = new HorseController();

        try {
            this.allHorses = horseController.getAllHorses();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }

        for (HorseEntity auto : this.allHorses) {
            comboChoices.add(auto.getHorseName());
        }

        horseChoice.setItems(FXCollections.observableArrayList(comboChoices));
        horseChoice.setValue(comboChoices.get(0));

        ArrayList<Integer> gradeList = new ArrayList<>();
        gradeList.add(1);
        gradeList.add(2);
        gradeList.add(3);
        gradeList.add(4);
        gradeList.add(5);
        this.gradeBox.setItems(FXCollections.observableArrayList(gradeList));
    }

    public void horseChange(ActionEvent actionEvent) {
        String horseName = this.horseChoice.getValue();

        Set<HorseEntity> reviewedHorses = new HashSet<>();

        HorseController horseController = new HorseController();

        try {
            reviewedHorses = horseController.getReviewedHorses(LogInSession.getLoggedInUser().getUserId());
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        if (UtilitiesClass.findHorseByName(horseName, reviewedHorses) != null) {
            this.horseWarningText.setText("You already wrote a review for this horse.");
        }
        else {
            this.horseWarningText.setText("");
        }
    }

    public void onSubmitClick(ActionEvent actionEvent) {

        String horseName = this.horseChoice.getValue();

        Set<HorseEntity> reviewedHorses = new HashSet<>();

        HorseController horseController = new HorseController();

        try {
            reviewedHorses = horseController.getReviewedHorses(LogInSession.getLoggedInUser().getUserId());
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        if (UtilitiesClass.findHorseByName(horseName, reviewedHorses) != null) {
            this.horseWarningText.setText("You already wrote a review for this horse.");
        }
        else {
            this.horseWarningText.setText("");
            if (this.reviewField.getText().isEmpty()) this.anotherWarningText.setText("Please write the review before pressing Submit.");
            else {
                if (this.gradeBox.getValue() == null) this.anotherWarningText.setText("Please choose a grade.");
                else {
                    HorseReviewController horseReviewController = new HorseReviewController();
                    HorseReviewEntity newReview = new HorseReviewEntity();
                    newReview.setUserId(LogInSession.getLoggedInUser().getUserId());
                    newReview.setHorseId(Objects.requireNonNull(UtilitiesClass.findHorseByName(horseName, this.allHorses)).getHorseId());
                    newReview.setReview(this.reviewField.getText());
                    newReview.setGrade(this.gradeBox.getValue());
                    horseReviewController.addReviewToDB(newReview);
                    this.changeScene(SCENE_IDENTIFIER.LOGGED_IN);
                    this.anotherWarningText.setText("");
                    this.reviewField.clear();
                }
            }
        }
    }

    public void onCancelClick(ActionEvent actionEvent) {
        this.changeScene(SCENE_IDENTIFIER.LOGGED_IN);
        this.reviewField.clear();
    }
}
