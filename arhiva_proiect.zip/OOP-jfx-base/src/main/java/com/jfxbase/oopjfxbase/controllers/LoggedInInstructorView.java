package com.jfxbase.oopjfxbase.controllers;

import com.jfxbase.oopjfxbase.dbcontrollers.HorseRidingCourseController;
import com.jfxbase.oopjfxbase.utils.InstructorCourseUtil;
import com.jfxbase.oopjfxbase.utils.SceneController;
import com.jfxbase.oopjfxbase.utils.enums.SCENE_IDENTIFIER;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.ResourceBundle;
import java.util.Stack;

public class LoggedInInstructorView extends SceneController implements Initializable {

    @FXML
    private TextField searchField;
    @FXML
    private RadioButton instructorcb;
    @FXML
    private RadioButton studentcb;
    @FXML
    private RadioButton horsecb;
    @FXML
    private RadioButton datecb;
    @FXML
    private RadioButton hourcb;
    @FXML
    private CheckBox onlyFutureCB;
    @FXML
    private TableView<InstructorCourseUtil> displayCoursesTable;
    @FXML
    private TableColumn<InstructorCourseUtil, String> instructorCol;
    @FXML
    private TableColumn<InstructorCourseUtil, String> studentCol;
    @FXML
    private TableColumn<InstructorCourseUtil, String> horseCol;
    @FXML
    private TableColumn<InstructorCourseUtil, LocalDate> dateCol;
    @FXML
    private TableColumn<InstructorCourseUtil, String> hourCol;
    private Stack<ArrayList<InstructorCourseUtil>> myLocalStack;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        this.loadDate();
        //filterContent();

        //ArrayList<InstructorCourseUtil> displayedCourses = new ArrayList<>(this.displayCoursesTable.getItems());
//        FilteredList<InstructorCourseUtil> filteredList = new FilteredList<>(this.displayCoursesTable.getItems(), b -> true);
//
//        this.searchField.setOnKeyReleased(e -> {
//            this.searchField.textProperty().addListener((observable, oldValue, newValue) -> {
//                filteredList.setPredicate(searchModel -> {
//
//                    if (this.searchField.getText() == null || this.searchField.getText().isEmpty() || this.searchField.getText().isBlank()) {
//                        return true;
//                    }
//
//                    String searchValue = this.searchField.getText().toLowerCase();
//
//                    return searchModel.getNameOfInstructor().toLowerCase().contains(searchValue);
//                });
//
//            });
//        });
    }

    private void loadDate() {
        this.instructorCol.setCellValueFactory(new PropertyValueFactory<>("nameOfInstructor"));
        this.studentCol.setCellValueFactory(new PropertyValueFactory<>("nameOfStudent"));
        this.horseCol.setCellValueFactory(new PropertyValueFactory<>("nameOfHorse"));
        this.dateCol.setCellValueFactory(new PropertyValueFactory<>("dateOfCourse"));
        this.hourCol.setCellValueFactory(new PropertyValueFactory<>("startingHour"));

        this.myLocalStack = new Stack<>();

        this.refreshTable();
    }

    private void refreshTable() {

        HorseRidingCourseController instructorController = new HorseRidingCourseController();

        ArrayList<InstructorCourseUtil> coursesToShow = instructorController.getAllCourses();

        this.displayCoursesTable.setItems(FXCollections.observableArrayList(coursesToShow));
    }

    public void onLogOutClick(ActionEvent actionEvent) {
        this.changeScene(SCENE_IDENTIFIER.HELLO);
    }

    public void showOnlyFuture(ActionEvent actionEvent) {

        ArrayList<InstructorCourseUtil> coursesToDisplay = new ArrayList<>(new ArrayList<>(this.displayCoursesTable.getItems()));
        if (this.onlyFutureCB.isSelected()) {
            //this.myLocalStack.push(new ArrayList<>(this.displayCoursesTable.getItems()));

            coursesToDisplay.removeIf(course -> course.getDateOfCourse().isBefore(LocalDate.now().plusDays(1)));
            this.displayCoursesTable.setItems(FXCollections.observableArrayList(coursesToDisplay));
        }
        else {
            //coursesToDisplay.addAll(this.myLocalStack.peek());
            //this.myLocalStack.pop();

            HorseRidingCourseController controller = new HorseRidingCourseController();
            coursesToDisplay = controller.getAllCourses();

            this.filterContent();

//            if (this.instructorcb.isSelected()) this.sortByInstructor();
//            else if (this.horsecb.isSelected()) this.sortByHorse();
//            else if (this.studentcb.isSelected()) this.sortByStudent();
//            else if (this.datecb.isSelected()) this.sortByDate();
//            else if (this.horsecb.isSelected()) this.sortByHour();
//            else this.displayCoursesTable.setItems(FXCollections.observableArrayList(coursesToDisplay));
        }
    }

    public void sortByInstructor() {
        ArrayList<InstructorCourseUtil> coursesToDisplay = new ArrayList<>();

        if (this.instructorcb.isSelected()) {
            this.myLocalStack.push(new ArrayList<>(this.displayCoursesTable.getItems()));
            coursesToDisplay.addAll(new ArrayList<>(this.displayCoursesTable.getItems()));
            coursesToDisplay.sort(Comparator.comparing(InstructorCourseUtil::getNameOfInstructor));
            this.displayCoursesTable.setItems(FXCollections.observableArrayList(coursesToDisplay));
        }
//        else {
//            coursesToDisplay.addAll(this.myLocalStack.peek());
//            this.myLocalStack.pop();
//            this.displayCoursesTable.setItems(FXCollections.observableArrayList(coursesToDisplay));
//        }
    }

    public void sortByStudent() {

        if (this.studentcb.isSelected()) {
            //this.myLocalStack.push(new ArrayList<>(this.displayCoursesTable.getItems()));
            ArrayList<InstructorCourseUtil> coursesToDisplay = new ArrayList<>(new ArrayList<>(this.displayCoursesTable.getItems()));
            coursesToDisplay.sort(Comparator.comparing(InstructorCourseUtil::getNameOfStudent));
            this.displayCoursesTable.setItems(FXCollections.observableArrayList(coursesToDisplay));
        }
//        else {
//            coursesToDisplay.addAll(this.myLocalStack.peek());
//            this.myLocalStack.pop();
//            this.displayCoursesTable.setItems(FXCollections.observableArrayList(coursesToDisplay));
//        }
    }

    public void sortByHorse() {

        if (this.horsecb.isSelected()) {
            //this.myLocalStack.push(new ArrayList<>(this.displayCoursesTable.getItems()));
            ArrayList<InstructorCourseUtil> coursesToDisplay = new ArrayList<>(new ArrayList<>(this.displayCoursesTable.getItems()));
            coursesToDisplay.sort(Comparator.comparing(InstructorCourseUtil::getNameOfHorse));
            this.displayCoursesTable.setItems(FXCollections.observableArrayList(coursesToDisplay));
        }
//        else {
//            coursesToDisplay.addAll(this.myLocalStack.peek());
//            this.myLocalStack.pop();
//            this.displayCoursesTable.setItems(FXCollections.observableArrayList(coursesToDisplay));
//        }
    }

    public void sortByDate() {

        if (this.datecb.isSelected()) {
            //this.myLocalStack.push(new ArrayList<>(this.displayCoursesTable.getItems()));
            ArrayList<InstructorCourseUtil> coursesToDisplay = new ArrayList<>(new ArrayList<>(this.displayCoursesTable.getItems()));
            coursesToDisplay.sort(Comparator.comparing(InstructorCourseUtil::getDateOfCourse));
            this.displayCoursesTable.setItems(FXCollections.observableArrayList(coursesToDisplay));
        }
//        else {
//            coursesToDisplay.addAll(this.myLocalStack.peek());
//            this.myLocalStack.pop();
//            this.displayCoursesTable.setItems(FXCollections.observableArrayList(coursesToDisplay));
//        }
    }

    public void sortByHour() {

        if (this.hourcb.isSelected()) {
            //this.myLocalStack.push(new ArrayList<>(this.displayCoursesTable.getItems()));
            ArrayList<InstructorCourseUtil> coursesToDisplay = new ArrayList<>(new ArrayList<>(this.displayCoursesTable.getItems()));
            coursesToDisplay.sort(Comparator.comparing(InstructorCourseUtil::getStartingHour));
            this.displayCoursesTable.setItems(FXCollections.observableArrayList(coursesToDisplay));
        }
//        else {
//            coursesToDisplay.addAll(this.myLocalStack.peek());
//            this.myLocalStack.pop();
//            this.displayCoursesTable.setItems(FXCollections.observableArrayList(coursesToDisplay));
//        }
    }

    public void filterContent() {
        HorseRidingCourseController controller = new HorseRidingCourseController();
        ArrayList<InstructorCourseUtil> allCourses = controller.getAllCourses();

        ArrayList<InstructorCourseUtil> futureCourses = new ArrayList<>(allCourses);
        futureCourses.removeIf(course -> course.getDateOfCourse().isBefore(LocalDate.now()));

        String searchName = this.searchField.getText();
        ArrayList<InstructorCourseUtil> filteredCourses = new ArrayList<>();

        if (this.onlyFutureCB.isSelected()) {
            if (searchName != null) {
                for (InstructorCourseUtil course : futureCourses) {
                    if (course.getNameOfInstructor().toLowerCase().contains(searchName.toLowerCase()))
                        filteredCourses.add(course);
                }
            }
        } else if (!this.onlyFutureCB.isSelected()) {
            if (searchName != null) {
                for (InstructorCourseUtil course : allCourses) {
                    if (course.getNameOfInstructor().toLowerCase().contains(searchName.toLowerCase()))
                        filteredCourses.add(course);
                }
            }
        }

        //this.displayCoursesTable.setItems(FXCollections.observableArrayList(filteredCourses));
        if (this.instructorcb.isSelected()) filteredCourses.sort(Comparator.comparing(InstructorCourseUtil::getNameOfInstructor));
        else if (this.horsecb.isSelected()) filteredCourses.sort(Comparator.comparing(InstructorCourseUtil::getNameOfHorse));
        else if (this.studentcb.isSelected()) filteredCourses.sort(Comparator.comparing(InstructorCourseUtil::getNameOfStudent));
        else if (this.datecb.isSelected()) filteredCourses.sort(Comparator.comparing(InstructorCourseUtil::getDateOfCourse));
        else if (this.hourcb.isSelected()) filteredCourses.sort(Comparator.comparing(InstructorCourseUtil::getStartingHour));

        this.displayCoursesTable.setItems(FXCollections.observableArrayList(filteredCourses));



//        ArrayList<InstructorCourseUtil> displayedCourses = new ArrayList<>(this.displayCoursesTable.getItems());
//        FilteredList<InstructorCourseUtil> filteredList = new FilteredList<>(this.displayCoursesTable.getItems(), b -> true);
//
//        this.searchField.textProperty().addListener((observable, oldValue, newValue) -> {
//            filteredList.setPredicate(searchModel -> {
//
//                if (this.searchField.getText() == null || this.searchField.getText().isEmpty() || this.searchField.getText().isBlank()) {
//                    return true;
//                }
//
//                String searchValue = this.searchField.getText().toLowerCase();
//
//                if (searchModel.getNameOfInstructor().toLowerCase().contains(searchValue)) return true;
//                else return false;
//            });
//
//        });

    }
}
