package com.jfxbase.oopjfxbase.dbcontrollers;

import com.jfxbase.oopjfxbase.mappedentities.HorseReviewEntity;
import com.jfxbase.oopjfxbase.utils.HorseReviewUtil;

import java.sql.*;
import java.util.HashSet;
import java.util.Set;

public class HorseReviewController extends DBController {
    public void addReviewToDB(HorseReviewEntity newInstance) {
        String msg;
        try {
            Connection connectionToPostgres = DriverManager.getConnection(super.DB_URL, super.USERNAME, super.PASSWORD);

            Statement stmt = connectionToPostgres.createStatement();
            String sql = "INSERT INTO horse_review (user_id, horse_id, review, grade)" + "VALUES (?, ?, ?, ?)";

            PreparedStatement preparedStatement = connectionToPostgres.prepareStatement(sql);
            preparedStatement.setInt(1, newInstance.getUserId());
            preparedStatement.setInt(2, newInstance.getHorseId());
            preparedStatement.setString(3, newInstance.getReview());
            preparedStatement.setInt(4, newInstance.getGrade());

            int addedRows = preparedStatement.executeUpdate();
            if (addedRows > 0) {
                msg = "Successful insertion into database.";
            }
            else {
                msg = "Unsuccessful insertion into database.";
            }

            stmt.close();
            connectionToPostgres.close();
        }
        catch (SQLException e) {
            msg = "Error establishing the connection.";
        }
    }

    public Set<HorseReviewUtil> getAllReviews() throws SQLException {

        Set<HorseReviewUtil> allReviews = new HashSet<>();

        Connection connectionToPostgres = DriverManager.getConnection(super.DB_URL, super.USERNAME, super.PASSWORD);

        String sql = "select * from horse_review hr join horse h on hr.horse_id = h.horse_id";

        PreparedStatement preparedStatement = connectionToPostgres.prepareStatement(sql);

        ResultSet resultSet = preparedStatement.executeQuery();

        while (resultSet.next()) {
            HorseReviewUtil foundReview = new HorseReviewUtil();
            foundReview.setNameOfHorse(resultSet.getString("horse_name"));
            foundReview.setReview(resultSet.getString("review"));
            foundReview.setGrade(resultSet.getInt("grade"));
            allReviews.add(foundReview);
        }

        return allReviews;
    }
}
