package com.jfxbase.oopjfxbase.dbcontrollers;

import com.jfxbase.oopjfxbase.mappedentities.HorseEntity;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class HorseController extends DBController{
    public Set<HorseEntity> getAllHorses() throws SQLException {

        Set<HorseEntity> allHorses = new HashSet<>();

        Connection connectionToPostgres = DriverManager.getConnection(super.DB_URL, super.USERNAME, super.PASSWORD);

        String sql = "select * from horse";

        PreparedStatement preparedStatement = connectionToPostgres.prepareStatement(sql);

        ResultSet resultSet = preparedStatement.executeQuery();

        while (resultSet.next()) {
            HorseEntity foundHorse = new HorseEntity();
            foundHorse.setHorseId(resultSet.getInt("horse_id"));
            foundHorse.setHorseName(resultSet.getString("horse_name"));
            foundHorse.setBreed(resultSet.getString("breed"));
            foundHorse.setBirthday(resultSet.getDate("birthday"));
            foundHorse.setOwnerId(resultSet.getInt("owner_id"));
            allHorses.add(foundHorse);
        }

        return allHorses;
    }

    public Set<HorseEntity> getReviewedHorses(Integer userId) throws SQLException {

        Set<HorseEntity> ReviewedHorses = new HashSet<>();

        Connection connectionToPostgres = DriverManager.getConnection(super.DB_URL, super.USERNAME, super.PASSWORD);

        String sql = "select * from horse h " +
                     "join horse_review hr on h.horse_id = hr.horse_id " +
                     "join users u on hr.user_id = u.user_id " +
                     "where hr.user_id = ?";

        PreparedStatement preparedStatement = connectionToPostgres.prepareStatement(sql);
        preparedStatement.setInt(1, userId);

        ResultSet resultSet = preparedStatement.executeQuery();

        while (resultSet.next()) {
            HorseEntity foundHorse = new HorseEntity();
            foundHorse.setHorseId(resultSet.getInt("horse_id"));
            foundHorse.setHorseName(resultSet.getString("horse_name"));
            foundHorse.setBreed(resultSet.getString("breed"));
            foundHorse.setBirthday(resultSet.getDate("birthday"));
            foundHorse.setOwnerId(resultSet.getInt("owner_id"));
            ReviewedHorses.add(foundHorse);
        }

        return ReviewedHorses;
    }
}
