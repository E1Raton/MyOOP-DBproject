package com.jfxbase.oopjfxbase.controllers;

import com.jfxbase.oopjfxbase.mappedentities.UserEntity;
import com.jfxbase.oopjfxbase.utils.LogInSession;
import com.jfxbase.oopjfxbase.utils.SceneController;
import com.jfxbase.oopjfxbase.utils.enums.SCENE_IDENTIFIER;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.text.Text;

public class LoggedInController extends SceneController{
    @FXML
    private Button seeCoursesBt;
    @FXML
    private Text WelcomeMsg;

    @FXML
    protected void onSayHelloClick() {
        this.WelcomeMsg.setText("Welcome, " + LogInSession.getLoggedInUser().getFirstName() + "!");
    }

    @FXML
    protected void onProgramCourseClick() {
        this.changeScene(SCENE_IDENTIFIER.PROGRAM_COURSE);
    }

    @FXML
    protected void onLogOutClick() {
        this.changeScene(SCENE_IDENTIFIER.HELLO);
        LogInSession.setLoggedInUser(null);
    }

    public void onReviewClick(ActionEvent actionEvent) {
        this.changeScene(SCENE_IDENTIFIER.REVIEW);
    }

    public void onSeeCoursesClick(ActionEvent actionEvent) {
        this.changeScene(SCENE_IDENTIFIER.DISPLAY_COURSES);
    }
}
