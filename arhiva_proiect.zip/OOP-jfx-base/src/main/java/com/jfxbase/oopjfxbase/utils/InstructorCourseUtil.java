package com.jfxbase.oopjfxbase.utils;

import java.time.LocalDate;

public class InstructorCourseUtil {
    private String nameOfInstructor;
    private String nameOfStudent;
    private String nameOfHorse;
    private LocalDate dateOfCourse;
    private String startingHour;
    private String courseCategory;
    private Integer studentId;
    private Integer horseId;

    public String getNameOfInstructor() {
        return nameOfInstructor;
    }

    public void setNameOfInstructor(String nameOfInstructor) {
        this.nameOfInstructor = nameOfInstructor;
    }

    public String getNameOfStudent() {
        return nameOfStudent;
    }

    public void setNameOfStudent(String nameOfStudent) {
        this.nameOfStudent = nameOfStudent;
    }

    public String getNameOfHorse() {
        return nameOfHorse;
    }

    public void setNameOfHorse(String nameOfHorse) {
        this.nameOfHorse = nameOfHorse;
    }

    public LocalDate getDateOfCourse() {
        return dateOfCourse;
    }

    public void setDateOfCourse(LocalDate dateOfCourse) {
        this.dateOfCourse = dateOfCourse;
    }

    public String getStartingHour() {
        return startingHour;
    }

    public void setStartingHour(String startingHour) {
        this.startingHour = startingHour;
    }

    public String getCourseCategory() {
        return courseCategory;
    }

    public void setCourseCategory(String courseCategory) {
        this.courseCategory = courseCategory;
    }

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public Integer getHorseId() {
        return horseId;
    }

    public void setHorseId(Integer horseId) {
        this.horseId = horseId;
    }
}
