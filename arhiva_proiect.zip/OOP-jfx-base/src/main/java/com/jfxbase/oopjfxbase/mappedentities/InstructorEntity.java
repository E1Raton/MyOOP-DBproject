package com.jfxbase.oopjfxbase.mappedentities;

public class InstructorEntity extends UserEntity{

}
