package com.jfxbase.oopjfxbase.utils;

import com.jfxbase.oopjfxbase.mappedentities.UserEntity;

public class LogInSession {
    private static UserEntity loggedInUser;

    public static UserEntity getLoggedInUser() {
        return loggedInUser;
    }

    public static void setLoggedInUser(UserEntity loggedInUser) {
        LogInSession.loggedInUser = loggedInUser;
    }
}
