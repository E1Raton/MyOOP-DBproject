package com.jfxbase.oopjfxbase.dbcontrollers;


import com.jfxbase.oopjfxbase.mappedentities.InstructorEntity;
import com.jfxbase.oopjfxbase.utils.InstructorCourseUtil;

import java.sql.*;
import java.util.ArrayList;

public class InstructorController extends DBController {

    public ArrayList<InstructorEntity> getAllInstructors() throws SQLException {

        ArrayList<InstructorEntity> allInstructors = new ArrayList<>();

        Connection connectionToPostgres = DriverManager.getConnection(super.DB_URL, super.USERNAME, super.PASSWORD);

        String sql = "select * from users join instructor on user_id = instructor_id";

        PreparedStatement preparedStatement = connectionToPostgres.prepareStatement(sql);

        ResultSet resultSet = preparedStatement.executeQuery();

        while (resultSet.next()) {
            InstructorEntity foundInstructor = new InstructorEntity();
            foundInstructor.setUserId(resultSet.getInt("instructor_id"));
            foundInstructor.setFirstName(resultSet.getString("firstname"));
            foundInstructor.setLastName(resultSet.getString("lastname"));
            allInstructors.add(foundInstructor);
        }

        return allInstructors;
    }

    public void addInstructorToDB(Integer id) {
        String msg;
        try {
            Connection connectionToPostgres = DriverManager.getConnection(super.DB_URL, super.USERNAME, super.PASSWORD);

            Statement stmt = connectionToPostgres.createStatement();
            String sql = "INSERT INTO instructor (instructor_id) " + "VALUES (?)";

            PreparedStatement preparedStatement = connectionToPostgres.prepareStatement(sql);
            preparedStatement.setInt(1, id);

            int addedRows = preparedStatement.executeUpdate();
            if (addedRows > 0) {
                msg = "Successful insertion into database.";
            }
            else {
                msg = "Unsuccessful insertion into database.";
            }

            stmt.close();
            connectionToPostgres.close();
        }
        catch (SQLException e) {
            msg = "Error establishing the connection.";
        }
    }

    public Boolean findInstructorInDB(Integer id) {
        boolean foundIt = false;
        try {
            Connection connectionToPostgres = DriverManager.getConnection(super.DB_URL, super.USERNAME, super.PASSWORD);

            String sql = "select * from instructor where instructor.instructor_id = ?";

            PreparedStatement preparedStatement = connectionToPostgres.prepareStatement(sql);
            preparedStatement.setInt(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) foundIt = true;

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return foundIt;
    }

//    public ArrayList<InstructorCourseUtil> getAllCourses() {
//        ArrayList<InstructorCourseUtil> instructorCourses = new ArrayList<>();
//
//        try {
//            Connection connectionToPostgres = DriverManager.getConnection(super.DB_URL, super.USERNAME, super.PASSWORD);
//
//            String sql = "select u1.firstname as ifirstname, u1.lastname as ilastname, " +
//                    "u2.firstname as sfirstname, u2.lastname as slastname, " +
//                    "h.horse_name, hrc.coursedate, hrc.starthour, cc.category_name " +
//                    "from instructor i " +
//                    "join users u1 on i.instructor_id = u1.user_id " +
//                    "join horseridingcourse hrc on i.instructor_id = hrc.instructor_id " +
//                    "join horse h on hrc.horse_id = h.horse_id " +
//                    "join coursecategory cc on hrc.category_id = cc.category_id " +
//                    "join student s on hrc.student_id = s.student_id " +
//                    "join users u2 on s.student_id = u2.user_id";
//
//            PreparedStatement preparedStatement = connectionToPostgres.prepareStatement(sql);
//
//            ResultSet resultSet = preparedStatement.executeQuery();
//
//            while (resultSet.next()) {
//                InstructorCourseUtil newInstructorCourse = new InstructorCourseUtil();
//                newInstructorCourse.setNameOfInstructor(resultSet.getString("ifirstname") + " " + resultSet.getString("ilastname"));
//                newInstructorCourse.setNameOfStudent(resultSet.getString("sfirstname") + " " + resultSet.getString("slastname"));
//                newInstructorCourse.setNameOfHorse(resultSet.getString("horse_name"));
//                newInstructorCourse.setDateOfCourse(resultSet.getDate("coursedate").toLocalDate());
//                newInstructorCourse.setStartingHour(resultSet.getString("starthour"));
//                newInstructorCourse.setCourseCategory(resultSet.getString("category_name"));
//
//                instructorCourses.add(newInstructorCourse);
//            }
//
//        } catch (SQLException e) {
//            System.out.println(e.getMessage());
//        }
//
//        return instructorCourses;
//    }
}
