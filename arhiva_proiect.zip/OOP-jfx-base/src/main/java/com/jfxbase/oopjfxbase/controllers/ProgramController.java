package com.jfxbase.oopjfxbase.controllers;

import com.jfxbase.oopjfxbase.dbcontrollers.CourseCategoryController;
import com.jfxbase.oopjfxbase.dbcontrollers.HorseController;
import com.jfxbase.oopjfxbase.dbcontrollers.HorseRidingCourseController;
import com.jfxbase.oopjfxbase.dbcontrollers.InstructorController;
import com.jfxbase.oopjfxbase.mappedentities.CourseCategoryEntity;
import com.jfxbase.oopjfxbase.mappedentities.HorseEntity;
import com.jfxbase.oopjfxbase.mappedentities.HorseRidingCourseEntity;
import com.jfxbase.oopjfxbase.mappedentities.InstructorEntity;
import com.jfxbase.oopjfxbase.utils.LogInSession;
import com.jfxbase.oopjfxbase.utils.SceneController;
import com.jfxbase.oopjfxbase.utils.Validator;
import com.jfxbase.oopjfxbase.utils.enums.SCENE_IDENTIFIER;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.text.Text;

import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.Set;

public class ProgramController extends SceneController implements Initializable {

    @FXML
    public Text dateText;

    @FXML
    private ComboBox<String> categoryBox;

    @FXML
    private CheckBox showDetails;
    
    @FXML
    private Text detailText;

    @FXML
    private ComboBox<String> instructorBox;

    @FXML
    private ComboBox<String> horseBox;

    @FXML
    private DatePicker dateField;

    @FXML
    private ComboBox<String> hourBox;

    @FXML
    private Text hourText;

    @FXML
    private Text validateText;

    private ArrayList<InstructorEntity> instructors;
    private ArrayList<CourseCategoryEntity> categories;
    private Set<HorseEntity> horses;
    private ArrayList<String> availableHours;

    private String getDetailText(String categoryName) {
        for (CourseCategoryEntity auto : this.categories) {
            if (auto.getCategoryName().equals(categoryName)) {
                return auto.getDescription();
            }
        }
        return null;
    }

    private Integer findCategoryId(String categoryName) {
        for (CourseCategoryEntity auto : this.categories) {
            if (auto.getCategoryName().equals(categoryName)) {
                return auto.getCategoryId();
            }
        }
        return null;
    }

    private Integer findInstructorId(String nameOfInstructor) {
        for (InstructorEntity auto : this.instructors) {
            if (nameOfInstructor.equals(auto.getFirstName() + " " + auto.getLastName())) {
                return auto.getUserId();
            }
        }
        return null;
    }

    private Integer findHorseId(String nameOfHorse) {
        for (HorseEntity auto : this.horses) {
            if (auto.getHorseName().equals(nameOfHorse)) {
                return auto.getHorseId();
            }
        }
        return null;
    }

    private void updateChoices(LocalDate courseDate, Integer horseId) {
        HorseRidingCourseController myController = new HorseRidingCourseController();

        Boolean[] pickedHours = new Boolean[this.availableHours.size()];
        for (int i = 0; i < this.availableHours.size(); i++) {
            try {
                pickedHours[i] = myController.checkForCourse(horseId, courseDate, this.availableHours.get(i));
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        ArrayList<String> remainingChoices = new ArrayList<>();
        for (int i = 0; i < pickedHours.length; i++) {
            if (pickedHours[i]) {
                remainingChoices.add(this.availableHours.get(i));
            }
        }

        this.hourBox.setItems(FXCollections.observableArrayList(remainingChoices));

        if (remainingChoices.isEmpty()) {
            this.hourText.setText("No available hours. Try to select other date or horse.");
        }
        else {
            this.hourText.setText("");
        }
    }

    public void initialize(URL url, ResourceBundle resourceBundle) {

        ArrayList<String> comboChoices = new ArrayList<>();

        CourseCategoryController categoryController = new CourseCategoryController();

        try {
            this.categories = categoryController.getAllCategories();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }

        for (CourseCategoryEntity auto : this.categories) {
            comboChoices.add(auto.getCategoryName());
        }

        categoryBox.setItems(FXCollections.observableArrayList(comboChoices));
        //categoryBox.setValue(comboChoices.get(0));

        comboChoices.clear();

        InstructorController instructorController = new InstructorController();

        try {
            this.instructors = instructorController.getAllInstructors();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }

        for (InstructorEntity auto : this.instructors) {
            comboChoices.add(auto.getFirstName() + " " + auto.getLastName());
        }

        instructorBox.setItems(FXCollections.observableArrayList(comboChoices));
        //instructorBox.setValue(comboChoices.get(0));

        comboChoices.clear();

        HorseController horseController = new HorseController();

        try {
            this.horses = horseController.getAllHorses();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }

        for (HorseEntity auto : this.horses) {
            comboChoices.add(auto.getHorseName());
        }

        horseBox.setItems(FXCollections.observableArrayList(comboChoices));
        //horseBox.setValue(comboChoices.get(0));

        comboChoices.clear();

        this.availableHours = new ArrayList<>();

        this.availableHours.add("10:00");
        this.availableHours.add("11:00");
        this.availableHours.add("12:00");
        this.availableHours.add("13:00");

        hourBox.setItems(FXCollections.observableArrayList(this.availableHours));
        //hourBox.setValue(comboChoices.get(0));

        //comboChoices.clear();

        //this.dateField.setValue(LocalDate.now());
    }
    
    @FXML
    protected void onShowDetailsClick() {
        if (this.showDetails.isSelected()) {
            this.detailText.setText(this.getDetailText(this.categoryBox.getValue()));
        }
        else {
            this.detailText.setText("");
        }
    }

    @FXML
    protected void onCancelClick() {

        this.changeScene(SCENE_IDENTIFIER.LOGGED_IN);

    }

    @FXML
    protected void onSubmitClick() {

        if(this.categoryBox.getValue() == null || this.instructorBox.getValue() == null || this.horseBox.getValue() == null || this.dateField.getValue() == null || this.hourBox.getValue() == null) {
            this.validateText.setText("Please check that there is no empty field.");
        }
        else if (this.dateField.getValue().isAfter(LocalDate.now())){
            HorseRidingCourseEntity newCourse = new HorseRidingCourseEntity();
            newCourse.setCategoryId(this.findCategoryId(this.categoryBox.getValue()));
            newCourse.setInstructorId(this.findInstructorId(this.instructorBox.getValue()));
            newCourse.setHorseId(this.findHorseId(this.horseBox.getValue()));
            newCourse.setCourseDate(this.dateField.getValue());
            newCourse.setStartHour(this.hourBox.getValue());
            newCourse.setStudentId(LogInSession.getLoggedInUser().getUserId());

            HorseRidingCourseController myController = new HorseRidingCourseController();
            myController.addCourseToDB(newCourse);
            this.changeScene(SCENE_IDENTIFIER.LOGGED_IN);

            this.categoryBox.setValue(null);
            this.instructorBox.setValue(null);
            this.horseBox.setValue(null);
            this.dateField.setValue(null);
            this.hourBox.setValue(null);
        }
    }

    @FXML
    public void getDate(ActionEvent actionEvent) {
        LocalDate pickedDate = this.dateField.getValue();
        if (pickedDate != null) {
            if (pickedDate.isBefore(LocalDate.now())) {
                this.dateText.setText("Invalid Date!");
            }
            else {
                if (this.horseBox.getValue() != null) {
                    this.updateChoices(pickedDate, this.findHorseId(this.horseBox.getValue()));
                };
                this.dateText.setText("");
            }
        }
//        System.out.println(pickedDate.toString());
    }

    public void instructorChange(ActionEvent actionEvent) {
//        String instructorName = this.instructorBox.getValue();
//        if(instructorName.equals("Teodora Mara Moldovan")) {
//            ArrayList<String> comboChoices = new ArrayList<>();
//
//            comboChoices.add("10:00");
//
//            this.hourBox.setItems(FXCollections.observableArrayList(comboChoices));
//        }


        //this.updateChoices(this.dateField.getValue(), this.findHorseId(this.horseBox.getValue()));
    }

    public void horseChange(ActionEvent actionEvent) {
        if (this.dateField.getValue() != null && this.horseBox.getValue()!= null) {
            this.updateChoices(this.dateField.getValue(), this.findHorseId(this.horseBox.getValue()));
        }
    }

    public void hourChange(ActionEvent actionEvent) {
    }
}
