package com.jfxbase.oopjfxbase.dbcontrollers;

import com.jfxbase.oopjfxbase.mappedentities.CourseCategoryEntity;

import java.sql.*;
import java.util.ArrayList;

public class CourseCategoryController extends DBController{
    public ArrayList<CourseCategoryEntity> getAllCategories() throws SQLException {

        ArrayList<CourseCategoryEntity> allCategories = new ArrayList<>();

        Connection connectionToPostgres = DriverManager.getConnection(super.DB_URL, super.USERNAME, super.PASSWORD);

        String sql = "select * from coursecategory";

        PreparedStatement preparedStatement = connectionToPostgres.prepareStatement(sql);

        ResultSet resultSet = preparedStatement.executeQuery();

        while (resultSet.next()) {
            CourseCategoryEntity foundCategory = new CourseCategoryEntity();
            foundCategory.setCategoryId(resultSet.getInt("category_id"));
            foundCategory.setCategoryName(resultSet.getString("category_name"));
            foundCategory.setDescription(resultSet.getString("description"));
            allCategories.add(foundCategory);
        }

        return allCategories;
    }

    public String getCategoryDescription(String categoryName) throws SQLException {

        Connection connectionToPostgres = DriverManager.getConnection(super.DB_URL, super.USERNAME, super.PASSWORD);

        String sql = "select * from coursecategory where category_name = ?";

        PreparedStatement preparedStatement = connectionToPostgres.prepareStatement(sql);
        preparedStatement.setString(1, categoryName);

        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            return resultSet.getString("description");
        }

        return null;
    }
}
