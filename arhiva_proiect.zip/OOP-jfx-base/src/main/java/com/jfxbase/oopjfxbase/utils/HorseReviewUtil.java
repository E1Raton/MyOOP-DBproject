package com.jfxbase.oopjfxbase.utils;

public class HorseReviewUtil {
    private String nameOfHorse;
    private String review;
    private Integer grade;

    public String getNameOfHorse() {
        return nameOfHorse;
    }

    public void setNameOfHorse(String nameOfHorse) {
        this.nameOfHorse = nameOfHorse;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public Integer getGrade() {
        return grade;
    }

    public void setGrade(Integer grade) {
        this.grade = grade;
    }
}
