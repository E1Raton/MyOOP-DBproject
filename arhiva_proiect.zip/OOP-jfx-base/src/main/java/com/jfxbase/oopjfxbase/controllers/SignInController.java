package com.jfxbase.oopjfxbase.controllers;

import com.jfxbase.oopjfxbase.dbcontrollers.InstructorController;
import com.jfxbase.oopjfxbase.dbcontrollers.StudentController;
import com.jfxbase.oopjfxbase.dbcontrollers.UserController;
import com.jfxbase.oopjfxbase.mappedentities.InstructorEntity;
import com.jfxbase.oopjfxbase.mappedentities.StudentEntity;
import com.jfxbase.oopjfxbase.mappedentities.UserEntity;
import com.jfxbase.oopjfxbase.utils.SceneController;
import com.jfxbase.oopjfxbase.utils.enums.SCENE_IDENTIFIER;
import javafx.fxml.FXML;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;

import java.sql.SQLException;
import java.util.ArrayList;

public class SignInController extends SceneController {
    @FXML
    private RadioButton rbInstructor;
    @FXML
    private RadioButton rbStudent;
    @FXML
    private TextField firstNameField;
    @FXML
    private TextField lastNameField;
    @FXML
    private TextField emailField;
    @FXML
    private TextField passwordField;
    @FXML
    private Text warningText;


    @FXML
    protected void onSignInClick() {
        String newUserEmail = emailField.getText();
        String newUserPassword = passwordField.getText();
        String newUserFirstname = firstNameField.getText();
        String newUserLastname = lastNameField.getText();

        if (newUserEmail.isEmpty() || newUserPassword.isEmpty() || newUserFirstname.isEmpty() || newUserLastname.isEmpty()) {
            this.warningText.setText("Please make sure you have completed all fields.");
        }
        else {
            if (!this.rbStudent.isSelected() && !this.rbInstructor.isSelected()) {
                this.warningText.setText("Please make a choice. Student or Instructor");
            }
            else {
                UserController controller = new UserController();
                ArrayList<UserEntity> allUsers = controller.getAllUsers();

                boolean validEmail = true;
                for (UserEntity user : allUsers) {
                    if (user.getEmail().toLowerCase().equals(this.emailField.getText())) validEmail = false;
                }

                if (!validEmail) {
                    this.warningText.setText("Invalid e-mail address.");
                } else {
                    this.warningText.setText("");
                    if (this.rbStudent.isSelected()) {
                        StudentEntity newInstance = new StudentEntity();
                        newInstance.setFirstName(this.firstNameField.getText());
                        newInstance.setLastName(this.lastNameField.getText());
                        newInstance.setEmail(this.emailField.getText());
                        newInstance.setPassword(this.passwordField.getText());

                        UserController newController = new UserController();
                        String msg = newController.addUserToDB(newInstance);
                        System.out.println(msg);

                        String userEmail = newInstance.getEmail();
                        String userPassword = newInstance.getPassword();

                        try {
                            UserEntity foundUser = newController.findUserInDB(userEmail, userPassword);
                            StudentController studentController = new StudentController();
                            msg = studentController.addStudentToDB(foundUser.getUserId());
                        } catch (SQLException e) {
                            System.out.println(e.getMessage());
                        }
                    }
                    else {
                        InstructorEntity newInstance = new InstructorEntity();
                        newInstance.setFirstName(this.firstNameField.getText());
                        newInstance.setLastName(this.lastNameField.getText());
                        newInstance.setEmail(this.emailField.getText());
                        newInstance.setPassword(this.passwordField.getText());

                        UserController newController = new UserController();
                        String msg = newController.addUserToDB(newInstance);
                        System.out.println(msg);

                        String userEmail = newInstance.getEmail();
                        String userPassword = newInstance.getPassword();

                        try {
                            UserEntity foundUser = newController.findUserInDB(userEmail, userPassword);
                            InstructorController instructorController = new InstructorController();
                            instructorController.addInstructorToDB(foundUser.getUserId());
                        } catch (SQLException e) {
                            System.out.println(e.getMessage());
                        }
                    }

                    this.changeScene(SCENE_IDENTIFIER.HELLO);

                    emailField.clear();
                    passwordField.clear();
                    firstNameField.clear();
                    lastNameField.clear();
                }
            }
        }
    }

    @FXML
    protected void onGoBackClick() {
        this.changeScene(SCENE_IDENTIFIER.HELLO);
        this.emailField.clear();
        this.passwordField.clear();
        this.firstNameField.clear();
        this.lastNameField.clear();
//        this.rbStudent.fire();
//        this.rbStudent.fire();
        this.warningText.setText("");
    }
}
