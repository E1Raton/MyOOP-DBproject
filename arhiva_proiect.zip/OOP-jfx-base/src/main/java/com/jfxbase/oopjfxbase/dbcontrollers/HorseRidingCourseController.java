package com.jfxbase.oopjfxbase.dbcontrollers;

import com.jfxbase.oopjfxbase.mappedentities.HorseRidingCourseEntity;
import com.jfxbase.oopjfxbase.utils.InstructorCourseUtil;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;

public class HorseRidingCourseController extends DBController {
    public Boolean checkForCourse(Integer horseId, LocalDate courseDate, String startingHour) throws SQLException {
        Connection connectionToPostgres = DriverManager.getConnection(super.DB_URL, super.USERNAME, super.PASSWORD);

        String sql = "select * from horseridingcourse where horse_id = ? and coursedate = ? and starthour = ?";

        PreparedStatement preparedStatement = connectionToPostgres.prepareStatement(sql);
        preparedStatement.setInt(1, horseId);
        preparedStatement.setDate(2, Date.valueOf(courseDate));
        preparedStatement.setString(3, startingHour);

        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            return false;
        }
        else {
            return true;
        }
    }

    public void addCourseToDB(HorseRidingCourseEntity newInstance) {
        String msg;
        try {
            Connection connectionToPostgres = DriverManager.getConnection(super.DB_URL, super.USERNAME, super.PASSWORD);

            Statement stmt = connectionToPostgres.createStatement();
            String sql = "INSERT INTO horseridingcourse (coursedate, horse_id, category_id, instructor_id, student_id, starthour)" + "VALUES (?, ?, ?, ?, ?, ?)";

            PreparedStatement preparedStatement = connectionToPostgres.prepareStatement(sql);
            preparedStatement.setDate(1, Date.valueOf(newInstance.getCourseDate()));
            preparedStatement.setInt(2, newInstance.getHorseId());
            preparedStatement.setInt(3, newInstance.getCategoryId());
            preparedStatement.setInt(4, newInstance.getInstructorId());
            preparedStatement.setInt(5, newInstance.getStudentId());
            preparedStatement.setString(6, newInstance.getStartHour());

            int addedRows = preparedStatement.executeUpdate();
            if (addedRows > 0) {
                msg = "Successful insertion into database.";
            }
            else {
                msg = "Unsuccessful insertion into database.";
            }

            stmt.close();
            connectionToPostgres.close();
        }
        catch (SQLException e) {
            msg = "Error establishing the connection.";
        }
    }

    public ArrayList<InstructorCourseUtil> getAllCourses() {
        ArrayList<InstructorCourseUtil> instructorCourses = new ArrayList<>();

        try {
            Connection connectionToPostgres = DriverManager.getConnection(super.DB_URL, super.USERNAME, super.PASSWORD);

            String sql = "select u1.firstname as ifirstname, u1.lastname as ilastname, " +
                    "u2.firstname as sfirstname, u2.lastname as slastname, " +
                    "h.horse_id, h.horse_name, hrc.coursedate, hrc.starthour, cc.category_name, s.student_id " +
                    "from instructor i " +
                    "join users u1 on i.instructor_id = u1.user_id " +
                    "join horseridingcourse hrc on i.instructor_id = hrc.instructor_id " +
                    "join horse h on hrc.horse_id = h.horse_id " +
                    "join coursecategory cc on hrc.category_id = cc.category_id " +
                    "join student s on hrc.student_id = s.student_id " +
                    "join users u2 on s.student_id = u2.user_id";

            PreparedStatement preparedStatement = connectionToPostgres.prepareStatement(sql);

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                InstructorCourseUtil newInstructorCourse = new InstructorCourseUtil();
                newInstructorCourse.setNameOfInstructor(resultSet.getString("ifirstname") + " " + resultSet.getString("ilastname"));
                newInstructorCourse.setNameOfStudent(resultSet.getString("sfirstname") + " " + resultSet.getString("slastname"));
                newInstructorCourse.setNameOfHorse(resultSet.getString("horse_name"));
                newInstructorCourse.setDateOfCourse(resultSet.getDate("coursedate").toLocalDate());
                newInstructorCourse.setStartingHour(resultSet.getString("starthour"));
                newInstructorCourse.setCourseCategory(resultSet.getString("category_name"));
                newInstructorCourse.setStudentId(resultSet.getInt("student_id"));
                newInstructorCourse.setHorseId(resultSet.getInt("horse_id"));

                instructorCourses.add(newInstructorCourse);
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return instructorCourses;
    }

    public HorseRidingCourseEntity getCourse(Integer horseId, LocalDate courseDate, String startingHour) {
        HorseRidingCourseEntity horseRidingCourse = null;

        try {
            Connection connectionToPostgres = DriverManager.getConnection(super.DB_URL, super.USERNAME, super.PASSWORD);

            String sql = "select * from horseridingcourse where " +
                    "horse_id = ? and courseDate = ? and starthour = ?";

            PreparedStatement preparedStatement = connectionToPostgres.prepareStatement(sql);
            preparedStatement.setInt(1, horseId);
            preparedStatement.setDate(2, Date.valueOf(courseDate));
            preparedStatement.setString(3, startingHour);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                horseRidingCourse = new HorseRidingCourseEntity();
                horseRidingCourse.setCourseId(resultSet.getInt("course_id"));
                horseRidingCourse.setCourseDate(resultSet.getDate("coursedate").toLocalDate());
                horseRidingCourse.setStudentId(resultSet.getInt("student_id"));
                horseRidingCourse.setHorseId(resultSet.getInt("horse_id"));
                horseRidingCourse.setInstructorId(resultSet.getInt("instructor_id"));
                horseRidingCourse.setCategoryId(resultSet.getInt("category_id"));
                horseRidingCourse.setStartHour(resultSet.getString("starthour"));
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return horseRidingCourse;
    }
    public void deleteCourseFromDB(Integer courseId) {
        try {
            Connection connectionToPostgres = DriverManager.getConnection(super.DB_URL, super.USERNAME, super.PASSWORD);

            String sql = "delete from horseridingcourse where course_id = ?";

            PreparedStatement preparedStatement = connectionToPostgres.prepareStatement(sql);
            preparedStatement.setInt(1, courseId);

            int deletedRows = preparedStatement.executeUpdate();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}
