package com.jfxbase.oopjfxbase.controllers;

import com.jfxbase.oopjfxbase.dbcontrollers.HorseRidingCourseController;
import com.jfxbase.oopjfxbase.dbcontrollers.InstructorController;
import com.jfxbase.oopjfxbase.dbcontrollers.UserController;
import com.jfxbase.oopjfxbase.mappedentities.HorseRidingCourseEntity;
import com.jfxbase.oopjfxbase.utils.InstructorCourseUtil;
import com.jfxbase.oopjfxbase.utils.LogInSession;
import com.jfxbase.oopjfxbase.utils.SceneController;
import com.jfxbase.oopjfxbase.utils.enums.SCENE_IDENTIFIER;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;

public class DisplayCoursesController extends SceneController implements Initializable {
    @FXML
    private TableColumn<InstructorCourseUtil, String> instructorColp;
    @FXML
    private TableColumn<InstructorCourseUtil, String> categoryColp;
    @FXML
    private TableColumn<InstructorCourseUtil, String> horseColp;
    @FXML
    private TableColumn<InstructorCourseUtil, LocalDate> dateColp;
    @FXML
    private TableColumn<InstructorCourseUtil, String> hourColp;
    @FXML
    private TableColumn<InstructorCourseUtil, String> studentColp;
    @FXML
    private TableView<InstructorCourseUtil> pastCoursesView;


    @FXML
    private TableColumn<InstructorCourseUtil, String> instructorColf;
    @FXML
    private TableColumn<InstructorCourseUtil, String> categoryColf;
    @FXML
    private TableColumn<InstructorCourseUtil, String> horseColf;
    @FXML
    private TableColumn<InstructorCourseUtil, LocalDate> dateColf;
    @FXML
    private TableColumn<InstructorCourseUtil, String> hourColf;
    @FXML
    private TableColumn<InstructorCourseUtil, String> studentColf;
    @FXML
    private TableView<InstructorCourseUtil> futureCoursesView;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        this.loadDate();
    }

    private void loadDate() {
        this.instructorColp.setCellValueFactory(new PropertyValueFactory<>("nameOfInstructor"));
        this.categoryColp.setCellValueFactory(new PropertyValueFactory<>("courseCategory"));
        this.horseColp.setCellValueFactory(new PropertyValueFactory<>("nameOfHorse"));
        this.dateColp.setCellValueFactory(new PropertyValueFactory<>("dateOfCourse"));
        this.hourColp.setCellValueFactory(new PropertyValueFactory<>("startingHour"));
        this.studentColp.setCellValueFactory(new PropertyValueFactory<>("nameOfStudent"));

        this.instructorColf.setCellValueFactory(new PropertyValueFactory<>("nameOfInstructor"));
        this.categoryColf.setCellValueFactory(new PropertyValueFactory<>("courseCategory"));
        this.horseColf.setCellValueFactory(new PropertyValueFactory<>("nameOfHorse"));
        this.dateColf.setCellValueFactory(new PropertyValueFactory<>("dateOfCourse"));
        this.hourColf.setCellValueFactory(new PropertyValueFactory<>("startingHour"));
        this.studentColf.setCellValueFactory(new PropertyValueFactory<>("nameOfStudent"));
    }

    public void onActiveCoursesClick(ActionEvent actionEvent) {
        HorseRidingCourseController controller = new HorseRidingCourseController();
        ArrayList<InstructorCourseUtil> myCourses = controller.getAllCourses();

        myCourses.removeIf(course -> course.getDateOfCourse().isAfter(LocalDate.now()));

        Integer userId = -1;
        UserController userController = new UserController();
        try {
            userId = userController.findUserInDB(LogInSession.getLoggedInUser().getEmail(), LogInSession.getLoggedInUser().getPassword()).getUserId();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        Integer finalUserId = userId;
        myCourses.removeIf(course -> !course.getStudentId().equals(finalUserId));

        this.pastCoursesView.setItems(FXCollections.observableArrayList(myCourses));
    }

    public void onCancelCourseClick(ActionEvent actionEvent) {
        InstructorCourseUtil selectedCourse = this.futureCoursesView.getSelectionModel().getSelectedItem();
        if (selectedCourse != null) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation Dialog");
            alert.setHeaderText("Are you sure you want to perform this action?");

            // Set the OK button as the default button
            alert.getButtonTypes().setAll(ButtonType.OK, ButtonType.CANCEL);

            // Show the alert and wait for the user's response
            alert.showAndWait().ifPresent(response -> {
                if (response == ButtonType.OK) {
                    // Perform the action associated with OK button
                    ObservableList<InstructorCourseUtil> allFutureCourses = this.futureCoursesView.getItems();
                    allFutureCourses.remove(selectedCourse);

                    HorseRidingCourseController horseRidingCourseController = new HorseRidingCourseController();
                    HorseRidingCourseEntity horseRidingCourse = horseRidingCourseController.getCourse(selectedCourse.getHorseId(), selectedCourse.getDateOfCourse(), selectedCourse.getStartingHour());
                    horseRidingCourseController.deleteCourseFromDB(horseRidingCourse.getCourseId());
                    System.out.println("Action performed!");
                } else {
                    // User clicked Cancel or closed the dialog
                    System.out.println("Action canceled.");
                }
            });
        }
    }

    public void onGoBackClick(ActionEvent actionEvent) {
        this.changeScene(SCENE_IDENTIFIER.LOGGED_IN);
        this.pastCoursesView.setItems(null);
        this.futureCoursesView.setItems(null);
    }

    public void onFutureCoursesClick(ActionEvent actionEvent) {
        HorseRidingCourseController controller = new HorseRidingCourseController();
        ArrayList<InstructorCourseUtil> myCourses = controller.getAllCourses();

        myCourses.removeIf(course -> course.getDateOfCourse().isBefore(LocalDate.now()));

        Integer userId = -1;
        UserController userController = new UserController();
        try {
            userId = userController.findUserInDB(LogInSession.getLoggedInUser().getEmail(), LogInSession.getLoggedInUser().getPassword()).getUserId();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        Integer finalUserId = userId;
        myCourses.removeIf(course -> !course.getStudentId().equals(finalUserId));

        this.futureCoursesView.setItems(FXCollections.observableArrayList(myCourses));
    }
}
