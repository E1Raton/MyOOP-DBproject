package com.jfxbase.oopjfxbase.dbcontrollers;

import com.jfxbase.oopjfxbase.mappedentities.UserEntity;

import java.sql.*;
import java.util.ArrayList;

public class UserController extends DBController{
    public String addUserToDB(UserEntity newInstance) {
        String msg;
        try {
            Connection connectionToPostgres = DriverManager.getConnection(super.DB_URL, super.USERNAME, super.PASSWORD);

            Statement stmt = connectionToPostgres.createStatement();
            String sql = "INSERT INTO users (email, password, firstname, lastname)" + "VALUES (?, ?, ?, ?)";

            PreparedStatement preparedStatement = connectionToPostgres.prepareStatement(sql);
            preparedStatement.setString(1, newInstance.getEmail());
            preparedStatement.setString(2, newInstance.getPassword());
            preparedStatement.setString(3, newInstance.getFirstName());
            preparedStatement.setString(4, newInstance.getLastName());

            int addedRows = preparedStatement.executeUpdate();
            if (addedRows > 0) {
                msg = "Successful insertion into database.";
            }
            else {
                msg = "Unsuccessful insertion into database.";
            }

            stmt.close();
            connectionToPostgres.close();
        }
        catch (SQLException e) {
            msg = "Error establishing the connection.";
        }
        return msg;
    }

    public UserEntity findUserInDB(String email, String password) throws SQLException {
        UserEntity foundUser = null;

        Connection connectionToPostgres = DriverManager.getConnection(super.DB_URL, super.USERNAME, super.PASSWORD);

        String sql = "select * from users where email = ? and password = ?";

        PreparedStatement preparedStatement = connectionToPostgres.prepareStatement(sql);
        preparedStatement.setString(1, email);
        preparedStatement.setString(2, password);

        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            foundUser = new UserEntity();
            foundUser.setUserId(resultSet.getInt("user_id"));
            foundUser.setEmail(resultSet.getString("email"));
            foundUser.setPassword(resultSet.getString("password"));
            foundUser.setFirstName(resultSet.getString("firstname"));
            foundUser.setLastName(resultSet.getString("lastname"));
        }

        return foundUser;
    }

    public ArrayList<UserEntity> getAllUsers () {
        ArrayList<UserEntity> allUsers = new ArrayList<>();

        try {
            Connection connectionToPostgres = DriverManager.getConnection(super.DB_URL, super.USERNAME, super.PASSWORD);

            String sql = "select * from users";

            PreparedStatement preparedStatement = connectionToPostgres.prepareStatement(sql);

            ResultSet resultSet = preparedStatement.executeQuery();


            while (resultSet.next()) {
                UserEntity foundUser = new UserEntity();
                foundUser.setUserId(resultSet.getInt("user_id"));
                foundUser.setEmail(resultSet.getString("email"));
                foundUser.setPassword(resultSet.getString("password"));
                foundUser.setFirstName(resultSet.getString("firstname"));
                foundUser.setLastName(resultSet.getString("lastname"));

                allUsers.add(foundUser);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return allUsers;
    }
}
