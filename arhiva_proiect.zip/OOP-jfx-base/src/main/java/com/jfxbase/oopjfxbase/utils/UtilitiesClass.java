package com.jfxbase.oopjfxbase.utils;

import com.jfxbase.oopjfxbase.mappedentities.HorseEntity;

import java.util.Set;

public class UtilitiesClass {
    public static HorseEntity findHorseByName(String horseName, Set<HorseEntity> allHorses) {
        for (HorseEntity horse : allHorses) {
            if (horseName.equals(horse.getHorseName())) return horse;
        }
        return null;
    }
}
