package com.jfxbase.oopjfxbase.utils;

import com.jfxbase.oopjfxbase.mappedentities.HorseRidingCourseEntity;

public class Validator {
    public static Boolean checkHorseRidingCourse(HorseRidingCourseEntity horseRidingCourseEntity) {
        if (horseRidingCourseEntity.getCourseDate() == null) return false;
        if (horseRidingCourseEntity.getHorseId() == null) return false;
        if (horseRidingCourseEntity.getCategoryId() == null) return false;
        if (horseRidingCourseEntity.getInstructorId() == null) return false;
        if (horseRidingCourseEntity.getStudentId() == null) return false;
        if (horseRidingCourseEntity.getStartHour() == null) return false;
        return true;
    }
}
