package com.jfxbase.oopjfxbase.dbcontrollers;

public class DBController {
    final String DB_URL = "jdbc:postgresql://localhost:5432/horseriding";
    final String USERNAME = "postgres";
    final String PASSWORD = "H@ppySQL";
}
